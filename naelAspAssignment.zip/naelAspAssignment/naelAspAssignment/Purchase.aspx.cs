﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;
using System.Web.Configuration;
using System.IO;

namespace naelAspAssignment
{
    public partial class Purchase : System.Web.UI.Page
    {static string connectionString = WebConfigurationManager.ConnectionStrings["flowerShopDatabase"].ConnectionString;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnCactus_Click(object sender, ImageClickEventArgs e)
        {
            string queryString = "SELECT * FROM Products WHERE name= @name ";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection);


            sqlCommand.Parameters.Add("@name", SqlDbType.VarChar);
            sqlCommand.Parameters["@name"].Value = "cactus";



            try
            {
                sqlConnection.Open();

                SqlDataReader reader = sqlCommand.ExecuteReader();
                lbldisplay2.Text = " Item not available feel free send us an inqury and will update you soon";

                while (reader.Read())
                {
                    lbldisplay2.Text = "Cactus is available you can select more plants if you like!! ";
                   
                    lblproducts.Text += "Cactus" + "<BR>";
                    lblproducts.Visible = false;
                }

            }
            catch (Exception ex)
            {
                lbldisplay2.Text = ex.Message;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            
            
                
         



        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string fl = tbfl.Text;
            string[] firstlast = fl.Split(' ');
           
            string queryString = "SELECT * FROM Customers WHERE first_nam = @firstname and last_name = @lastname";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection);

            sqlCommand.Parameters.Add("@firstname", SqlDbType.VarChar);
            sqlCommand.Parameters["@firstname"].Value = firstlast[0];
            sqlCommand.Parameters.Add("@lastname", SqlDbType.VarChar);
            sqlCommand.Parameters["@lastname"].Value = firstlast[1];

            try
            {
                sqlConnection.Open();

                SqlDataReader reader = sqlCommand.ExecuteReader();
               lblSearchResult.Text = "please refere back to registation form";
               btnBuy.Enabled = false;
               while (reader.Read())
               {
                    lblSearchResult.Text = "welcome" +" "+fl+" Select your desired pants";
                    btnBuy.Enabled = true;
                }

            }
            catch (Exception ex)
            {
                lblSearchResult.Text = ex.Message;
            }
            finally
            {
                sqlConnection.Close();
            }
        
        }

        protected void btnJoranium_Click(object sender, ImageClickEventArgs e)
        {
            string queryString = "SELECT * FROM Products WHERE name= @name ";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection);
     

            sqlCommand.Parameters.Add("@name", SqlDbType.VarChar);
                    sqlCommand.Parameters["@name"].Value = "jeranium";
                    
            

            try
            {
                sqlConnection.Open();

                SqlDataReader reader = sqlCommand.ExecuteReader();
                lbldisplay2.Text = " Item not available feel free send us an inqury and will update you soon";
               
                while (reader.Read())
                {
                    lbldisplay2.Text = "jeranium is available you can select more plants if you like!! ";
                    
                    lblproducts.Text += "jeranium" + "<BR>";
                    lblproducts.Visible = false;
                }

            }
            catch (Exception ex)
            {
                lbldisplay2.Text = ex.Message;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        protected void btnRose_Click(object sender, ImageClickEventArgs e)
        {
            string queryString = "SELECT * FROM Products WHERE name= @name ";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection);


            sqlCommand.Parameters.Add("@name", SqlDbType.VarChar);
            sqlCommand.Parameters["@name"].Value = "rose";



            try
            {
                sqlConnection.Open();

                SqlDataReader reader = sqlCommand.ExecuteReader();
                lbldisplay2.Text = " Item not available feel free send us an inqury and will update you soon";

                while (reader.Read())
                {
                    lbldisplay2.Text = "Rose is available you can select more plants if you like!! ";
                    lblproducts.Text += "Rose" + "<BR>";
                    lblproducts.Visible = false;
                    btnBuy.Enabled = true;
                }

            }
            catch (Exception ex)
            {
                lbldisplay2.Text = ex.Message;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        protected void btnDasies_Click(object sender, ImageClickEventArgs e)
        {
            
            string queryString = "SELECT * FROM Products WHERE name= @name ";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection);


            sqlCommand.Parameters.Add("@name", SqlDbType.VarChar);
            sqlCommand.Parameters["@name"].Value = "daisy";



            try
            {
                sqlConnection.Open();

                SqlDataReader reader = sqlCommand.ExecuteReader();
                lbldisplay2.Text = " Item not available feel free send us an inqury and will update you soon";

                while (reader.Read())
                {
                    lbldisplay2.Text = "Daisey is available you can select more plants if you like!! ";
                    
                    lblproducts.Text += "Daise" +"<BR>";
                    lblproducts.Visible = false;
                }

            }
            catch (Exception ex)
            {
                lbldisplay2.Text = ex.Message;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        protected void btnBuy_Click(object sender, EventArgs e)
        {
            
            lblfinal.Text += "<BR>Dear Valued " +""+ tbfl.Text +""+ "you have purchased" +"<BR>" +lblproducts.Text;
           
        }
    }
}