﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;
using System.Web.Configuration;

namespace naelAspAssignment
{
    public partial class NewCustomerRegistration : System.Web.UI.Page
    {
        static string connectionString = WebConfigurationManager.ConnectionStrings["flowerShopDatabase"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnreg_Click(object sender, EventArgs e)
        {
            string fname = txtfname.Text;
            string lname = txtlname.Text;
            string email = txtemail.Text;
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand("INSERT INTO customers VALUES ('"
                + fname + "', '" + lname + "',' " + email + "')",
                sqlConnection);
            try
            {
                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                lblred.Text = "Saved successfully!";
            }
            catch (Exception ex)
            {
                lblred.Text = ex.ToString();
            }
            finally
            {
                sqlConnection.Close();
            }
        }
    }
}