﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;
using System.Web.Configuration;

namespace naelAspAssignment
{
    public partial class EditProductsForm : System.Web.UI.Page
    { static string connectionString = WebConfigurationManager.ConnectionStrings["flowerShopDatabase"].ConnectionString;
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsr_Click(object sender, EventArgs e)
        {
            string queryString = "SELECT * FROM products WHERE name = @name";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection);

            sqlCommand.Parameters.Add("@name", SqlDbType.VarChar);
            sqlCommand.Parameters["@name"].Value = txtsr.Text;try
            {
                sqlConnection.Open();
                
                SqlDataReader reader = sqlCommand.ExecuteReader();
                lblSearchResult.Text = "";
                while (reader.Read())
                {
                    lblSearchResult.Text += "<BR>ID: " + reader[0];
                    lblSearchResult.Text += "<BR>Name: " + reader[1];
                    lblSearchResult.Text += "<BR>Price: " + reader[2];
                    lblSearchResult.Text += "<BR>Quantity: " + reader[3];
                    lblSearchResult.Text += "<BR>Color: " + reader[4];
                }

            }
            catch (Exception ex)
            {
                lblSearchResult.Text = ex.Message;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        protected void btnPrice_Click(object sender, EventArgs e)
        {
              string queryString = "UPDATE products SET price = @price WHERE ID = @ID";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection);

            sqlCommand.Parameters.Add("@ID", SqlDbType.BigInt);
            sqlCommand.Parameters["@ID"].Value = txtID.Text;

            sqlCommand.Parameters.Add("@price", SqlDbType.Decimal);
            sqlCommand.Parameters["@price"].Value = txtp.Text;

            try
            {
                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                lblp.Text = "the item with ID:" + txtID.Text + " price updated successfully";
            }
            catch (Exception ex)
            {
                lblp.Text = ex.ToString();
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
              string queryString = "UPDATE products SET quantity = @quantity WHERE ID = @ID";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection);

            sqlCommand.Parameters.Add("@ID", SqlDbType.BigInt);
            sqlCommand.Parameters["@ID"].Value = txtidq.Text;

            sqlCommand.Parameters.Add("@quantity", SqlDbType.SmallInt);
            sqlCommand.Parameters["@quantity"].Value = txtq2.Text;

            try
            {
                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                lblq1.Text = txtID.Text + " Quantity updated successfully";
            }
            catch (Exception ex)
            {
                lblq1.Text = ex.ToString();
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        protected void btnD_Click(object sender, EventArgs e)
        {
            {
                string queryString = "DELETE FROM products WHERE ID = @ID";
                SqlConnection sqlConnection = new SqlConnection(connectionString);
                SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection);

                sqlCommand.Parameters.Add("@ID", SqlDbType.BigInt);
                sqlCommand.Parameters["@ID"].Value = txtid3.Text;

                try
                {
                    sqlConnection.Open();
                    //smart version - tells you number of items deleted
                    int n = sqlCommand.ExecuteNonQuery();
                    if (n == 0)
                    {
                        lbldel1.Text = "None found";
                    }
                    else
                    {
                        lbldel1.Text = n + " items deleted successfully";
                    }
                }
                catch (Exception ex)
                {
                    lbldel1.Text = ex.ToString();
                }
                finally
                {
                    sqlConnection.Close();
                }
            }
        }

        protected void btngo0_Click(object sender, EventArgs e)
        {

        }
    }
        }
    
        
        
    
