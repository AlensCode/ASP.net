﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;
using System.Web.Configuration;

namespace naelAspAssignment
{
    public partial class NewProductForm : System.Web.UI.Page
    {
        static string connectionString = WebConfigurationManager.ConnectionStrings["flowerShopDatabase"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
             
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            string queryString = "INSERT INTO dbo.Products VALUES (@Name, @Price, @Quantity, @Color);";

            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection);

            sqlCommand.Parameters.Add("@Name", SqlDbType.VarChar);
            sqlCommand.Parameters["@Name"].Value = txtName.Text;
            sqlCommand.Parameters.Add("@Price", SqlDbType.Decimal);
            sqlCommand.Parameters["@Price"].Value = txtPrice.Text;
            sqlCommand.Parameters.Add("@Quantity", SqlDbType.SmallInt);
            sqlCommand.Parameters["@Quantity"].Value = txtQuantity.Text;
            sqlCommand.Parameters.Add("@Color", SqlDbType.VarChar);
            sqlCommand.Parameters["@Color"].Value = txtColor.Text;

            try
            {
                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
               lbldisplay.Text = txtName.Text + " added successfully.";
            }
            catch (Exception ex)
            {
                lbldisplay.Text = ex.ToString();
            }
            finally
            {
                sqlConnection.Close();
            }
        }
    }
}